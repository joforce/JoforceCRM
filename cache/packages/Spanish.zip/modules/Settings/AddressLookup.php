<?php

$languageStrings = array(
        'AddressLookup'         => 'Búsqueda de dirección',
        'Address Lookup'        => 'Búsqueda de dirección',
        'LBL_STREET'            => 'Calle',
        'LBL_ENTER_API_KEY'     => 'Ingrese su clave de API',
        'LBL_CLICK_TO_CREATE_API_KEY'   => 'Haga clic aquí para crear la clave de la API',
        'LBL_AREA'                      => 'Zona',
        'LBL_LOCALITY'                  => 'Localidad',
        'LBL_CITY'                      => 'Ciudad',
        'LBL_STATE'                     => 'Estado',
        'LBL_COUNTRY'                   => 'País',
        'LBL_POSTAL_CODE'               => 'Código postal',
        'LBL_ACTION'                    => 'Acción',
        'LBL_CONFIGURE_MAPPING_FOR'     => 'Configurar la asignación de campos para',
);
