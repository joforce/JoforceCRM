<?php

$languageStrings = array(
        'DuplicateCheck' => 'Comprobación duplicada',
        'Duplicate Check' => 'Comprobación duplicada',
        'LBL_DUPLICATECHECK_INFORMATION' => 'Información de verificación duplicada',
        'LBL_CLICK'             => 'Hacer clic',
        'LBL_CROSSCHECK'        => 'Para la verificación cruzada',
        'LBL_DULICATECHECK_RULE_FOR'    => 'Regla de verificación duplicada para',
        'LBL_ENABLE'                    => 'Habilitar',
        'LBL_DISABLE'                   => 'Inhabilitar',
        'LBL_CONFIGURE_FIELD_RULE'      => 'Configurar la regla de campo',
        'LBL_CHOOSE_CHECK_MODULE'       => 'Para elegir qué controlar en este módulo',
        'LBL_CHECK_DUPLICATE'           => 'Comprobar duplicados en contactos, clientes potenciales y organización para correo electrónico y campo de teléfono',
);
