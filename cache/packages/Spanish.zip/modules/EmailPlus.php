<?php
$languageStrings = array(
        'LBL_ACCOUNT_TYPE'      =>'Tipo de cuenta',
        'LBL_SERVER_NAME'       =>'Nombre del servidor',
        'LBL_PORT'              =>'Puerto',
        'LBL_EMAIL'             =>'Correo electrónico principal',
        'LBL_PASSWORD'          =>'Contraseña',
);
