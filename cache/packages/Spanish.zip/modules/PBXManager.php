<?php
/*+**********************************************************************************
 * The contents of this file are subject to the vtiger CRM Public License Version 1.0
 * ("License"); You may not use this file except in compliance with the License
 * The Original Code is:  vtiger CRM Open Source
 * The Initial Developer of the Original Code is vtiger.
 * Portions created by vtiger are Copyright (C) vtiger.
 * Portions created by JPL TSolucio, S.L. are Copyright (C) jpl tsolucio.
 * All Rights Reserved.
 * Contributor(s): JoForce.com
 * ********************************************************************************
 *  Language     : Español es_es
 *  Version      : 6.0.0
 *  Created Date : 2012-10-26
 *  Author       : JPL TSolucio, S. L. Joe Bordes
 *  Last change  : 2012-10-26
 *  Author       : JPL TSolucio, S. L. Joe Bordes
 ************************************************************************************/
$languageStrings = array(
	'Asterisk'                     => 'Asterisk',
	'PBXManager'                   => 'Administrador PBX',
	'SINGLE_PBXManager'            => 'Administrador PBX',
	'LBL_CALL_INFORMATION'         => 'Detalles Llamada',
	'Call From'                    => 'Llamada de',
	'Call To'                      => 'Llamar a',
	'Time Of Call'                 => 'Tiempo de Llamada',
	'PBXManager ID'                => 'Id Administrador PBX',
	//Blocks
    	'LBL_PBXMANAGER_INFORMATION' => 'Detalles de la llamada',
    	'LBL_CUSTOM_INFORMATION'=>'Información personalizada',

    	// list view settings links
    	'LBL_SERVER_CONFIGURATION' => 'Configuración de proveedor',

    	//Detail view header title
    	'LBL_CALL_FROM' => 'Llamad desde',
    	'LBL_CALL_TO' => 'Llamado a la',

    	//Incoming call pop-up 
    	'LBL_HIDDEN' => '(Oculto)',

    	// Fields
    	'Total Duration' => 'Duración (seg)',
    	'Bill Duration'  => 'Bill Duración (seg)',
);
