<?php

$languageStrings = array(
        'SINGLE_PDFMaker' => 'PDF Maker',
        'PDFMaker' => 'PDF Maker',
        'LBL_NAME' => 'Nombre',
        'LBL_DESCRIPTION' => 'Descripción',
        'LBL_TEMPLATE' => 'Modelo',
        'LBL_PDFMAKER_INFORMATION' => 'Información de PDF Maker',
        'LBL_SELECT_FIELD_TYPE' => 'Seleccione tipo',
        'LBL_NO_TEMPLATE' => 'No existe una plantilla para este módulo',
        'LBL_GENERAL' => 'General',
        'LBL_COMPANY_INFO' => 'Información de la compañía'
);
