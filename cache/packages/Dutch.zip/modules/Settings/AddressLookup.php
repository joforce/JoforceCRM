<?php

$languageStrings = array(
        'AddressLookup'         => 'Adres opzoeken',
        'Address Lookup'        => 'Adres opzoeken',
        'LBL_STREET'            => 'Straat',
        'LBL_ENTER_API_KEY'     => 'Voer uw API-sleutel in',
        'LBL_CLICK_TO_CREATE_API_KEY'   => 'Klik hier om de API-sleutel te maken',
        'LBL_AREA'                      => 'Gebied',
        'LBL_LOCALITY'                  => 'Plaats',
        'LBL_CITY'                      => 'stad',
        'LBL_STATE'                     => 'Staat',
        'LBL_COUNTRY'                   => 'land',
        'LBL_POSTAL_CODE'               => 'Postcode',
        'LBL_ACTION'                    => 'Actie',
        'LBL_CONFIGURE_MAPPING_FOR'     => 'Veldtoewijzing configureren voor',
);
