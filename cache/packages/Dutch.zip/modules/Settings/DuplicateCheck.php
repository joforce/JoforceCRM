<?php

$languageStrings = array(
        'DuplicateCheck' => 'Dubbele controle',
        'Duplicate Check' => 'Dubbele controle',
        'LBL_DUPLICATECHECK_INFORMATION' => 'Dubbele controle-informatie',
        'LBL_CLICK'             => 'Klik',
        'LBL_CROSSCHECK'        => 'Voor Cross Check',
        'LBL_DULICATECHECK_RULE_FOR'    => 'Duplicate Check Rule For',
        'LBL_ENABLE'                    => 'in staat stellen',
        'LBL_DISABLE'                   => 'onbruikbaar maken',
        'LBL_CONFIGURE_FIELD_RULE'      => 'Veldregel configureren',
        'LBL_CHOOSE_CHECK_MODULE'       => 'Om te kiezen wat u in deze module wilt inchecken',
        'LBL_CHECK_DUPLICATE'           => 'Controleer Duplicaten in Contacten, Leads en Organisatie voor e-mail en telefoonveld',
);
