<?php
$languageStrings = array(
        'LBL_ACCOUNT_TYPE'      =>'Account Type',
        'LBL_SERVER_NAME'       =>'Server Naam' ,
        'LBL_PORT'              =>'Haven',
        'LBL_EMAIL'             =>'Primaire email',
        'LBL_PASSWORD'          =>'Wachtwoord',
);
