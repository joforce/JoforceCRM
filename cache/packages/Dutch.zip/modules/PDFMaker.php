<?php

$languageStrings = array(
        'SINGLE_PDFMaker' => 'PDF Maker',
        'PDFMaker' => 'PDF Maker',
        'LBL_NAME' => 'Naam',
        'LBL_DESCRIPTION' => 'Beschrijving',
        'LBL_TEMPLATE' => 'Sjabloon',
        'LBL_PDFMAKER_INFORMATION' => 'PDFMaker-informatie',
        'LBL_SELECT_FIELD_TYPE' => 'Selecteer type',
        'LBL_NO_TEMPLATE' => 'Er bestaat geen sjabloon voor deze module',
        'LBL_GENERAL' => 'Algemeen',
        'LBL_COMPANY_INFO' => 'Bedrijfsinformatie'
);
