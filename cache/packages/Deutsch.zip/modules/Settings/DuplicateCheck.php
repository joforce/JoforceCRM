<?php

$languageStrings = array(
        'DuplicateCheck' => 'Doppelter Check',
        'Duplicate Check' => 'Doppelter Check',
        'LBL_DUPLICATECHECK_INFORMATION' => 'Doppelte Überprüfungsinformationen',
        'LBL_CLICK'             => 'Klicken',
        'LBL_CROSSCHECK'        => 'Für Kreuzprüfung',
        'LBL_DULICATECHECK_RULE_FOR'    => 'Duplikatprüfungsregel für',
        'LBL_ENABLE'                    => 'Aktivieren',
        'LBL_DISABLE'                   => 'Deaktivieren',
        'LBL_CONFIGURE_FIELD_RULE'      => 'Konfigurieren Sie die Feldregel',
        'LBL_CHOOSE_CHECK_MODULE'       => 'Wählen Sie, was in diesem Modul überprüft werden soll',
        'LBL_CHECK_DUPLICATE'           => 'Dubletten über Kontakte, Leads und Organisation für E-Mail- und Telefonfeld prüfen',
);
