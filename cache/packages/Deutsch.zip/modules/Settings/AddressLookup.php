<?php

$languageStrings = array(
        'AddressLookup'         => 'Adressensuche',
        'Address Lookup'        => 'Adressensuche',
        'LBL_STREET'            => 'Straße',
        'LBL_ENTER_API_KEY'     => 'Geben Sie Ihren API-Schlüssel ein',
        'LBL_CLICK_TO_CREATE_API_KEY'   => 'Klicken Sie hier, um den API-Schlüssel zu erstellen',
        'LBL_AREA'                      => 'Bereich',
        'LBL_LOCALITY'                  => 'Lokalität',
        'LBL_CITY'                      => 'Stadt',
        'LBL_STATE'                     => 'Zustand',
        'LBL_COUNTRY'                   => 'Land',
        'LBL_POSTAL_CODE'               => 'Postleitzahl',
        'LBL_ACTION'                    => 'Aktion',
        'LBL_CONFIGURE_MAPPING_FOR'     => 'Feldzuordnung konfigurieren für',
);
