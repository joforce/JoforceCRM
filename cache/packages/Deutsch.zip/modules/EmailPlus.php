<?php
$languageStrings = array(
        'LBL_ACCOUNT_TYPE'      =>'Konto Typ',
        'LBL_SERVER_NAME'       =>'Server Name' ,
        'LBL_PORT'              =>'Hafen',
        'LBL_EMAIL'             =>'Erste Email',
        'LBL_PASSWORD'          =>'Passwort',
);
