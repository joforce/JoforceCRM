<?php

$languageStrings = array(
        'SINGLE_PDFMaker' => 'PDF Maker',
        'PDFMaker' => 'PDF Maker',
        'LBL_NAME' => 'Name',
        'LBL_DESCRIPTION' => 'Beschreibung',
        'LBL_TEMPLATE' => 'Vorlage',
        'LBL_PDFMAKER_INFORMATION' => 'PDF-Herstellerinformationen',
        'LBL_SELECT_FIELD_TYPE' => 'Art auswählen',
        'LBL_NO_TEMPLATE' => 'Für dieses Modul existiert keine Vorlage',
        'LBL_GENERAL' => 'Allgemeines',
        'LBL_COMPANY_INFO' => 'Unternehmensinformationen',
);
