<?php

$languageStrings = array(
        'SINGLE_PDFMaker' => 'PDF Maker',
        'PDFMaker' => 'PDF Maker',
        'LBL_NAME' => 'Nome',
        'LBL_DESCRIPTION' => 'iDescrição',
        'LBL_TEMPLATE' => 'Modelo',
        'LBL_PDFMAKER_INFORMATION' => 'Informações do Criador de PDF',
        'LBL_SELECT_FIELD_TYPE' => 'selecione o tipo',
        'LBL_NO_TEMPLATE' => 'Nenhum modelo existe para este módulo',
        'LBL_GENERAL' => 'Geral',
        'LBL_COMPANY_INFO' => 'Informações da empresa'
);
