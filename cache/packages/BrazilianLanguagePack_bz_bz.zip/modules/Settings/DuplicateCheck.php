<?php

$languageStrings = array(
        'DuplicateCheck' => 'Cheque Duplicado',
        'Duplicate Check' => 'Cheque Duplicado',
        'LBL_DUPLICATECHECK_INFORMATION' => 'DuplicateCheck Information',
        'LBL_CLICK'             => 'Clique',
        'LBL_CROSSCHECK'        => 'Para Cross Check',
        'LBL_DULICATECHECK_RULE_FOR'    => 'Regra de verificação duplicada para',
        'LBL_ENABLE'                    => 'Habilitar',
        'LBL_DISABLE'                   => 'Desabilitar',
        'LBL_CONFIGURE_FIELD_RULE'      => 'Configurar regra de campo',
        'LBL_CHOOSE_CHECK_MODULE'       => 'Para escolher o que verificar neste módulo',
        'LBL_CHECK_DUPLICATE'           => 'Verificar duplicatas em contatos, leads e organização para email e telefone',
);
