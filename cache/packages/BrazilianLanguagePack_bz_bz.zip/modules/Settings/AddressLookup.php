<?php

$languageStrings = array(
        'AddressLookup'         => 'Pesquisa de endereço',
        'Address Lookup'        => 'Pesquisa de endereço',
        'LBL_STREET'            => 'Rua',
        'LBL_ENTER_API_KEY'     => 'Insira sua chave de API',
        'LBL_CLICK_TO_CREATE_API_KEY'   => 'Clique aqui para criar uma chave de API',
        'LBL_AREA'                      => 'Área',
        'LBL_LOCALITY'                  => 'Localidade',
        'LBL_CITY'                      => 'Cidade',
        'LBL_STATE'                     => 'Estado',
        'LBL_COUNTRY'                   => 'País',
        'LBL_POSTAL_CODE'               => 'Código postal',
        'LBL_ACTION'                    => 'Açao',
        'LBL_CONFIGURE_MAPPING_FOR'     => 'Configurar o mapeamento de campo para',
);
