<?php
$languageStrings = array(
        'LBL_ACCOUNT_TYPE'      =>'tipo de conta',
        'LBL_SERVER_NAME'       =>'Nome do servidor' ,
        'LBL_PORT'              =>'Porta',
        'LBL_EMAIL'             =>'E-mail primário',
        'LBL_PASSWORD'          =>'Senha',
);
