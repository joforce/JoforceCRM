<?php

$languageStrings = array(
        'DuplicateCheck' => 'Повторная проверка',
        'Duplicate Check' => 'Повторная проверка',
        'LBL_DUPLICATECHECK_INFORMATION' => 'Повторная проверка Информация',
        'LBL_CLICK'             => 'щелчок',
        'LBL_CROSSCHECK'        => 'Для проверки кросс',
        'LBL_DULICATECHECK_RULE_FOR'    => 'Повторяющееся правило проверки для',
        'LBL_ENABLE'                    => 'включить',
        'LBL_DISABLE'                   => 'запрещать',
        'LBL_CONFIGURE_FIELD_RULE'      => 'Настроить полевое правило',
        'LBL_CHOOSE_CHECK_MODULE'       => 'Чтобы выбрать, что нужно проверить в этом модуле',
        'LBL_CHECK_DUPLICATE'           => 'Проверка дубликатов контактов, контактов и организации для электронной почты и телефонного поля',
);
