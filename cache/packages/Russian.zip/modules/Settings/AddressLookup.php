<?php

$languageStrings = array(
        'AddressLookup'         => 'Поиск адреса',
        'Address Lookup'        => 'Поиск адреса',
        'LBL_STREET'            => 'улица',
        'LBL_ENTER_API_KEY'     => 'Введите свой ключ API',
        'LBL_CLICK_TO_CREATE_API_KEY'   => 'Нажмите здесь, чтобы создать ключ API',
        'LBL_AREA'                      => 'площадь',
        'LBL_LOCALITY'                  => 'Местонахождение',
        'LBL_CITY'                      => 'город',
        'LBL_STATE'                     => 'государство',
        'LBL_COUNTRY'                   => 'страна',
        'LBL_POSTAL_CODE'               => 'Почтовый индекс',
        'LBL_ACTION'                    => 'действие',
        'LBL_CONFIGURE_MAPPING_FOR'     => 'Настройка сопоставления полей для',
);
