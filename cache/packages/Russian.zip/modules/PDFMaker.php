<?php

$languageStrings = array(
        'SINGLE_PDFMaker' => 'PDF Maker',
        'PDFMaker' => 'PDF Maker',
        'LBL_NAME' => 'имя',
        'LBL_DESCRIPTION' => 'Описание',
        'LBL_TEMPLATE' => 'шаблон',
        'LBL_PDFMAKER_INFORMATION' => 'Информация о файле PDF',
        'LBL_SELECT_FIELD_TYPE' => 'Выберите тип',
        'LBL_NO_TEMPLATE' => 'iДля этого модуля не существует шаблона',
        'LBL_GENERAL' => 'Генеральная',
        'LBL_COMPANY_INFO' => 'Информация о компании',
);
