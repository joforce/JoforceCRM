<?php
$languageStrings = array(
        'LBL_ACCOUNT_TYPE'      =>'Тип аккаунта',
        'LBL_SERVER_NAME'       =>'iимя сервера' ,
        'LBL_PORT'              =>'порт',
        'LBL_EMAIL'             =>'Основной адрес электронной почты',
        'LBL_PASSWORD'          =>'пароль',
);
