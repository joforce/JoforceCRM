<?php
$languageStrings = array(
        'LBL_ACCOUNT_TYPE'      =>'hesap tipi',
        'LBL_SERVER_NAME'       =>'Sunucu adı',
        'LBL_PORT'              =>'Liman',
        'LBL_EMAIL'             =>'Öncelikli E-posta',
        'LBL_PASSWORD'          =>'Parola',
);
