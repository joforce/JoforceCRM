<?php
class Settings_DuplicateCheck_GetFieldsName_View extends Settings_Vtiger_Index_View{
	public function process(Vtiger_Request $request){
		global $adb;
		$arrayValues = [];
		extract($_GET);
		$modulename = $_GET['moduleName'];
		$runQuery = $adb->pquery("SELECT fieldstomatch FROM vtiger_vtduplicatechecksettings WHERE modulename='$modulename' AND isenabled='1'");
		$fetchValues = $adb->fetch_array($runQuery);
		$count = $adb->num_rows($runQuery);
		$explodedValues = explode(",",$fetchValues['fieldstomatch']);
		array_push($arrayValues,count($explodedValues));
		foreach ($explodedValues as $key => $value) {
			$runQuery = $adb->pquery("SELECT fieldname FROM vtiger_field WHERE fieldid='$value'");
			$fetchValues = $adb->fetch_array($runQuery);
			array_push($arrayValues,$fetchValues['fieldname']);
			# code...
		}
	
	    $response = new Vtiger_Response();
            $response->setEmitType(Vtiger_Response::$EMIT_JSON);
            $response->setResult(array($count,$arrayValues));
            $response->emit();
            die;
	}
}


