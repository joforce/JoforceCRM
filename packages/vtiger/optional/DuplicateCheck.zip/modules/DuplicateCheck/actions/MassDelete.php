<?php
/* +**********************************************************************************
 * The contents of this file are subject to the JoForce Public License Version 1.0
 * ("License"); You may not use this file except in compliance with the License
 * The Developer of the Original Code is JoForce.
 * All Rights Reserved.
 * ********************************************************************************** */

class DuplicateCheck_MassDelete_Action extends Vtiger_Mass_Action {

	function checkPermission(Vtiger_Request $request) {
		$moduleName = $request->getModule();
		$moduleModel = Vtiger_Module_Model::getInstance($moduleName);

		$currentUserPriviligesModel = Users_Privileges_Model::getCurrentUserPrivilegesModel();
		if(!$currentUserPriviligesModel->hasModuleActionPermission($moduleModel->getId(), 'Delete')) {
			throw new AppException('LBL_PERMISSION_DENIED');
		}
	}

	function preProcess(Vtiger_Request $request) {
		return true;
	}

	function postProcess(Vtiger_Request $request) {
		return true;
	}

	public function process(Vtiger_Request $request) {
		$moduleName = $request->getModule();
		$moduleModel = Vtiger_Module_Model::getInstance($moduleName);

		$recordIds = $this->getRecordsListFromRequest($request);

		foreach($recordIds as $recordId) 
		{
			if(Users_Privileges_Model::isPermitted($moduleName, 'Delete', $recordId)) 
			{
				$focus = array();
				$focus = CRMEntity::getInstance($moduleName);
		                $focus->id = $recordId;
                		$focus->retrieve_entity_info($recordId, $moduleName);
		                $modelClassName = Vtiger_Loader::getComponentClassName('Model', 'Record', $moduleName);
                		$instance = new $modelClassName();
		                $recordModel = $instance->setData($focus->column_fields)->set('id',$recordId)->setModuleFromInstance($moduleModel)->setEntity($focus);
				$recordModel->delete();
			}
		}

		$cvId = $request->get('viewname');
		$response = new Vtiger_Response();
		$response->setResult(array('viewname'=>$cvId, 'module'=>$moduleName));
		$response->emit();
	}
}
