<?php

$languageStrings = array(
        'SINGLE_VTPDFMaker' => 'PDF Maker',
        'VTPDFMaker' => 'PDF Maker',
	'LBL_NAME' => 'Name',
	'LBL_DESCRIPTION' => 'Description',
	'LBL_TEMPLATE' => 'Template',
	'LBL_PDFMAKER_INFORMATION' => 'PDFMaker Information',
	'LBL_SELECT_FIELD_TYPE' => 'Select Type',
	'LBL_NO_TEMPLATE' => 'No template exists for this module',
	'LBL_GENERAL' => 'General',
	'LBL_COMPANY_INFO' => 'Company Informations'
);
