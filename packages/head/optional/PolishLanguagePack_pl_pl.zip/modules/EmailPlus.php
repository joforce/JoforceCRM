<?php
$languageStrings = array(
        'LBL_ACCOUNT_TYPE'      =>'typ konta',
        'LBL_SERVER_NAME'       =>'Nazwa serwera',
        'LBL_PORT'              =>'Port',
        'LBL_EMAIL'             =>'Główny email',
        'LBL_PASSWORD'          =>'Hasło',
);
