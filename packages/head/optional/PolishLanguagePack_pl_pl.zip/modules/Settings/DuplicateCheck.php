<?php

$languageStrings = array(
        'DuplicateCheck' => 'Duplikuj czek',
        'Duplicate Check' => 'Duplikuj czek',
        'LBL_DUPLICATECHECK_INFORMATION' => 'Zduplikuj informacje kontrolne',
        'LBL_CLICK'             => 'Kliknij',
        'LBL_CROSSCHECK'        => 'Dla Cross Check',
        'LBL_DULICATECHECK_RULE_FOR'    => 'Duplikat Sprawdź regułę dla',
        'LBL_ENABLE'                    => 'Włączyć',
        'LBL_DISABLE'                   => 'Wyłączyć',
        'LBL_CONFIGURE_FIELD_RULE'      => 'Skonfiguruj regułę pola',
        'LBL_CHOOSE_CHECK_MODULE'       => 'Aby wybrać, co należy sprawdzić w tym module',
        'LBL_CHECK_DUPLICATE'           => 'Sprawdź duplikaty między kontaktami, namiarami i organizacją dla pola poczty e-mail i telefonu',
);
