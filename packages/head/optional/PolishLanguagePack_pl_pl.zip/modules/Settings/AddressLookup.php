<?php

$languageStrings = array(
        'AddressLookup'         => 'Wyszukiwanie adresu',
        'Address Lookup'        => 'Wyszukiwanie adresu',
        'LBL_STREET'            => 'Ulica',
        'LBL_ENTER_API_KEY'     => 'Wpisz swój klucz API',
        'LBL_CLICK_TO_CREATE_API_KEY'   => 'Kliknij tutaj, aby utworzyć klucz API',
        'LBL_AREA'                      => 'Powierzchnia',
        'LBL_LOCALITY'                  => 'Miejscowość',
        'LBL_CITY'                      => 'Miasto',
        'LBL_STATE'                     => 'Stan',
        'LBL_COUNTRY'                   => 'Kraj',
        'LBL_POSTAL_CODE'               => 'kod pocztowy',
        'LBL_ACTION'                    => 'Akcja',
        'LBL_CONFIGURE_MAPPING_FOR'     => 'Skonfiguruj mapowanie pól dla',
);
