<?php

$languageStrings = array(
        'SINGLE_PDFMaker' => 'PDF Maker',
        'PDFMaker' => 'PDF Maker',
        'LBL_NAME' => 'Nazwa',
        'LBL_DESCRIPTION' => 'Opis',
        'LBL_TEMPLATE' => 'Szablon',
        'LBL_PDFMAKER_INFORMATION' => 'Informacje o PDFMaker',
        'LBL_SELECT_FIELD_TYPE' => 'Wybierz rodzaj',
        'LBL_NO_TEMPLATE' => 'Dla tego modułu nie istnieje szablon',
        'LBL_GENERAL' => 'Generał',
        'LBL_COMPANY_INFO' => 'Informacje o firmie'
);
