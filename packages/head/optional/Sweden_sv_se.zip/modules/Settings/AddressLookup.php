<?php

$languageStrings = array(
        'AddressLookup'         => 'Adressuppsökning',
        'Address Lookup'        => 'Adressuppsökning',
        'LBL_STREET'            => 'Gata',
        'LBL_ENTER_API_KEY'     => 'Ange din API-nyckel',
        'LBL_CLICK_TO_CREATE_API_KEY'   => 'Klicka här för att skapa API-nyckel',
        'LBL_AREA'                      => 'Område',
        'LBL_LOCALITY'                  => 'Lokalitet',
        'LBL_CITY'                      => 'Stad',
        'LBL_STATE'                     => 'stat',
        'LBL_COUNTRY'                   => 'Land',
        'LBL_POSTAL_CODE'               => 'postnummer',
        'LBL_ACTION'                    => 'Handling',
        'LBL_CONFIGURE_MAPPING_FOR'     => 'Konfigurera fältmappning för',
);
