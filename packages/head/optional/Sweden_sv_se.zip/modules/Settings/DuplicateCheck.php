<?php

$languageStrings = array(
        'DuplicateCheck' => 'Duplicate Check',
        'Duplicate Check' => 'Duplicate Check',
        'LBL_DUPLICATECHECK_INFORMATION' => 'Duplikat kontrollinformation',
        'LBL_CLICK'             => 'Klick',
        'LBL_CROSSCHECK'        => 'För korskontroll',
        'LBL_DULICATECHECK_RULE_FOR'    => 'Duplicate Check Regel För',
        'LBL_ENABLE'                    => 'Gör det möjligt',
        'LBL_DISABLE'                   => 'inaktivera',
        'LBL_CONFIGURE_FIELD_RULE'      => 'Konfigurera fältregeln',
        'LBL_CHOOSE_CHECK_MODULE'       => 'Att välja vad som ska kontrolleras i den här modulen',
        'LBL_CHECK_DUPLICATE'           => 'Kontrollera dubbletter över kontakter, ledningar och organisation för e-post och telefonfält',
);
