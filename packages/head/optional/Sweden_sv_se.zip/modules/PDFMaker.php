<?php

$languageStrings = array(
        'SINGLE_PDFMaker' => 'PDF Maker',
        'PDFMaker' => 'PDF Maker',
        'LBL_NAME' => 'namn',
        'LBL_DESCRIPTION' => 'Beskrivning',
        'LBL_TEMPLATE' => 'Mall',
        'LBL_PDFMAKER_INFORMATION' => 'PDFMaker Information',
        'LBL_SELECT_FIELD_TYPE' => 'Välj typ',
        'LBL_NO_TEMPLATE' => 'Det finns ingen mall för denna modul',
        'LBL_GENERAL' => 'Allmän',
        'LBL_COMPANY_INFO' => 'Företagsinformation'
);
