<?php
$languageStrings = array(
        'LBL_ACCOUNT_TYPE'      =>'Kontotyp',
        'LBL_SERVER_NAME'       =>'Server namn',
        'LBL_PORT'              =>'Hamn',
        'LBL_EMAIL'             =>'Primär E-postadress',
        'LBL_PASSWORD'          =>'Lösenord',
);
