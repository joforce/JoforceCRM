<?php
/*+**********************************************************************************
 * The contents of this file are subject to the vtiger CRM Public License Version 1.0
 * ("License"); You may not use this file except in compliance with the License
 * The Original Code is:  vtiger CRM Open Source
 * The Initial Developer of the Original Code is vtiger.
 * Portions created by vtiger are Copyright (C) vtiger.
 * All Rights Reserved.
 * Contributor(s): JoForce.com
 ************************************************************************************/
$languageStrings = array(
	'Events'                       => 'Eventos'                     , 
	'SINGLE_Events'                => 'Evento'                      , 
	'LBL_ADD_RECORD'               => 'Agregar Evento'              , 
	'LBL_RECORDS_LIST'             => 'Vista de Lista'              , 
	'LBL_EVENTS'                   => 'Eventos'                     , 
	'LBL_TODOS'                    => 'Tarea'                      , 
	'LBL_HOLD_FOLLOWUP_ON'         => 'Mantenga Seguimiento On'     ,
    'LBL_CREATE_FOLLOWUP_EVENT'    => 'Crear Seguimiento de eventos',
	'LBL_EVENT_INFORMATION'        => 'Detalle del evento'          , 
	'LBL_RECURRENCE_INFORMATION'   => 'Detalles de recurrencia'     , 
	'LBL_RELATED_TO'               => 'Relacionado con'                  , // TODO: Review
	'Start Date & Time'            => 'Fecha y Hora de Inicio'      , 
	'Recurrence'                   => 'Recurrencia'                 , 
	'Send Notification'            => 'Enviar notificación'        , 
	'Location'                     => 'Lugar'                       , 
	'Send Reminder'                => 'Enviar recordatorio'         , 
	'End Date & Time'              => 'Fecha y Hora de Vencimiento' , 
    'End Date'                     => 'Fecha y Hora de Vencimiento' , 
	'Activity Type'                => 'Tipo de Actividad'           , 
	'Visibility'                   => 'Visibilidad'                 , 
	'Private'                      => 'Privado'                     , 
	'Public'                       => 'Publico'                     , 
	'Call'                         => 'Llamada'                     , 
	'Meeting'                      => 'Reunión'                    , 
	'Planned'                      => 'Planeada'                    , 
	'Held'                         => 'Mantenida'                   , 
	'Not Held'                     => 'No Mantenida'                , 
    'Related To'                   => 'En relación con'             ,
	'LBL_DAYS'                     => 'Días'                       , 
	'LBL_HOURS'                    => 'Horas'                       , 
	'LBL_DAYS_TYPE'                => 'Días(s)'                      , // TODO: Review
	'LBL_WEEKS_TYPE'               => 'Semana(s)'                     , // TODO: Review
	'LBL_MONTHS_TYPE'              => 'Mes(s)'                    , // TODO: Review
	'LBL_YEAR_TYPE'                => 'Año'                        , // TODO: Review
	'LBL_FIRST'                    => 'Primero'                       , // TODO: Review
	'LBL_LAST'                     => 'Último'                        , // TODO: Review
	'LBL_SM_SUN'                   => 'Dom'                         , // TODO: Review
	'LBL_SM_MON'                   => 'Lun'                         , // TODO: Review
	'LBL_SM_TUE'                   => 'Mar'                         , // TODO: Review
	'LBL_SM_WED'                   => 'Mié'                         , // TODO: Review
	'LBL_SM_THU'                   => 'Jue'                         , // TODO: Review
	'LBL_SM_FRI'                   => 'Vie'                         , // TODO: Review
	'LBL_SM_SAT'                   => 'Sáb'                         , // TODO: Review
	'LBL_DAY0'                     => 'Domingo'                      , // TODO: Review
	'LBL_DAY1'                     => 'Lunes'                      , // TODO: Review
	'LBL_DAY2'                     => 'Martes'                     , // TODO: Review
	'LBL_DAY3'                     => 'Miércoles'                   , // TODO: Review
	'LBL_DAY4'                     => 'Jueves'                    , // TODO: Review
	'LBL_DAY5'                     => 'Viernes'                      , // TODO: Review
	'LBL_DAY6'                     => 'Sábado'                    , // TODO: Review
	'LBL_DOMINGO'                  => 'Domingo'                      , // TODO: Review
	'LBL_LUNES'                    => 'Lunes'                      , // TODO: Review
	'LBL_MARTES'                   => 'Martes'                     , // TODO: Review
	'LBL_MIÉRCOLES'                => 'Miércoles'                   , // TODO: Review
	'LBL_JUEVES'                   => 'Jueves'                    , // TODO: Review
	'LBL_VIERNES'                  => 'Viernes'                      , // TODO: Review
	'LBL_SÁBADO'                   => 'Sábado'                    , // TODO: Review
	'Daily'                        => 'Día(s)'                      , // TODO: Review
	'Weekly'                       => 'Semana(s)'                     , // TODO: Review
	'Monthly'                      => 'Mes(s)'                    , // TODO: Review
	'Yearly'                       => 'Año'                        , // TODO: Review
	'LBL_RELATED_TO'               => 'Relacionado con',
	'LBL_REPEATEVENT'              => 'Una vez en cada'        , // TODO: Review
	'LBL_UNTIL'                    => 'Hasta'                       , // TODO: Review
	'LBL_DAY_OF_THE_MONTH'         => 'día del mes'            , // TODO: Review
	'LBL_ON'                       => 'en'                          , // TODO: Review
	'LBL_CALENDAR_VIEW'            => 'Vista de Calendario'         , 
	'LBL_INVITE_USER_BLOCK'        => 'Invitar'                      , // TODO: Review
	'LBL_INVITE_USERS'             => 'Invitar usuarios'                , // TODO: Review
        'LBL_INVITE_PEOPLE'            => 'Invitar Gente'               ,


  'INVITATION' => ' Invitación ',
  'Busy' => 'Ocupado',

);