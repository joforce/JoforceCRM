<?php
/*+**********************************************************************************
 * The contents of this file are subject to the vtiger CRM Public License Version 1.0
 * ("License"); You may not use this file except in compliance with the License
 * The Original Code is:  vtiger CRM Open Source
 * The Initial Developer of the Original Code is vtiger.
 * Portions created by vtiger are Copyright (C) vtiger.
 * All Rights Reserved.
 * Contributor(s): JoForce.com
 ************************************************************************************/
$languageStrings = array(
	'CronTasks'                    => 'Scheduler'                   , // TODO: Review
	'Id'                           => 'Id'                          , // TODO: Review
	'Cron Job'                     => 'Cron Job'                    , // TODO: Review
	'Frequency'                    => 'Frequency'                   , // TODO: Review
	'Status'                       => 'Status'                      , // TODO: Review
	'Last Start'                   => 'Last scan started'           , // TODO: Review
	'Last End'                     => 'Last scan ended'             , // TODO: Review
	'Sequence'                     => 'Sequence'                    , // TODO: Review
	'LBL_COMPLETED'                => 'Completed'                   , // TODO: Review
	'LBL_RUNNING'                  => 'Running'                     , // TODO: Review
	'LBL_ACTIVE'                   => 'Active'                      , // TODO: Review
	'LBL_INACTIVE'                 => 'In Active'                   , // TODO: Review
);