<?php

$languageStrings = array(
        'AddressLookup'         => 'Adresă de căutare',
        'Address Lookup'        => 'Adresă de căutare',
        'LBL_STREET'            => 'Stradă',
        'LBL_ENTER_API_KEY'     => 'Introduceți cheia API',
        'LBL_CLICK_TO_CREATE_API_KEY'   => 'Faceți clic aici pentru a crea cheia API',
        'LBL_AREA'                      => 'Zonă',
        'LBL_LOCALITY'                  => 'Localitate',
        'LBL_CITY'                      => 'Oraș',
        'LBL_STATE'                     => 'Stat',
        'LBL_COUNTRY'                   => 'Țară',
        'LBL_POSTAL_CODE'               => 'cod postal',
        'LBL_ACTION'                    => 'Acțiune',
        'LBL_CONFIGURE_MAPPING_FOR'     => 'Configurați maparea câmpului pentru',
);
