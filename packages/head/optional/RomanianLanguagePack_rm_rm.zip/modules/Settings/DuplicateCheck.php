<?php

$languageStrings = array(
        'DuplicateCheck' => 'Verificați duplicat',
        'Duplicate Check' => 'Verificați duplicat',
        'LBL_DUPLICATECHECK_INFORMATION' => 'Informații de verificare duplicate',
        'LBL_CLICK'             => 'Clic',
        'LBL_CROSSCHECK'        => 'Pentru verificarea încrucișată',
        'LBL_DULICATECHECK_RULE_FOR'    => 'Regulă de verificare duplicată pentru',
        'LBL_ENABLE'                    => 'Permite',
        'LBL_DISABLE'                   => 'Dezactivați',
        'LBL_CONFIGURE_FIELD_RULE'      => 'Configurați regula câmpului',
        'LBL_CHOOSE_CHECK_MODULE'       => 'Pentru a alege ce să verificați în acest modul',
        'LBL_CHECK_DUPLICATE'           => 'Verificați duplicate în Contacte, Lideri și Organizație pentru câmpul Email și Telefon',
);
