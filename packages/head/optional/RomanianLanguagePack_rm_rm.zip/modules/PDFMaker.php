<?php

$languageStrings = array(
        'SINGLE_PDFMaker' => 'Producător de PDF-uri',
        'PDFMaker' => 'Producător de PDF-uri',
        'LBL_NAME' => 'Nume',
        'LBL_DESCRIPTION' => 'Descriere',
        'LBL_TEMPLATE' => 'Format',
        'LBL_PDFMAKER_INFORMATION' => 'Producătorul de fișiere PDF Informații',
        'LBL_SELECT_FIELD_TYPE' => 'Selectați Tip',
        'LBL_NO_TEMPLATE' => 'Nu există șablon pentru acest modul',
        'LBL_GENERAL' => 'General',
        'LBL_COMPANY_INFO' => 'Informații despre companie'
);
