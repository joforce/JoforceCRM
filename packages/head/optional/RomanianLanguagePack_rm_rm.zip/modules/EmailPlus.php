<?php
$languageStrings = array(
        'LBL_ACCOUNT_TYPE'      =>'Tip de cont',
        'LBL_SERVER_NAME'       =>'Numele serverului' ,
        'LBL_PORT'              =>'Port',
        'LBL_EMAIL'             =>'Emailul principal',
        'LBL_PASSWORD'          =>'Parola',
);
