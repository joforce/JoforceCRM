<?php
$languageStrings = array(
        'LBL_ACCOUNT_TYPE'      =>'Account Type',
        'LBL_SERVER_NAME'       =>'Server Name' ,
        'LBL_PORT'              =>'Port',
        'LBL_EMAIL'             =>'Primary Email',
        'LBL_PASSWORD'          =>'Password',
);
