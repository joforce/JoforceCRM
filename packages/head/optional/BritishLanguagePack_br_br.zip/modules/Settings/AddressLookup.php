<?php

$languageStrings = array(
        'AddressLookup'         => 'Address Lookup',
        'Address Lookup'        => 'Address Lookup',
        'LBL_STREET'            => 'Street',
        'LBL_ENTER_API_KEY'     => 'Enter Your API Key',
        'LBL_CLICK_TO_CREATE_API_KEY'   => 'Click Here to Create API Key',
        'LBL_AREA'                      => 'Area',
        'LBL_LOCALITY'                  => 'Locality',
        'LBL_CITY'                      => 'City',
        'LBL_STATE'                     => 'State',
        'LBL_COUNTRY'                   => 'Country',
        'LBL_POSTAL_CODE'               => 'Postal Code',
        'LBL_ACTION'                    => 'Action',
        'LBL_CONFIGURE_MAPPING_FOR'     => 'Configure Field Mapping For',
);
