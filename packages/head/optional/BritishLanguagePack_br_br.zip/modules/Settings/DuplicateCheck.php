<?php

$languageStrings = array(
        'DuplicateCheck' => 'Duplicate Check',
        'Duplicate Check' => 'Duplicate Check',
        'LBL_DUPLICATECHECK_INFORMATION' => 'DuplicateCheck Information',
        'LBL_CLICK'             => 'Click',
        'LBL_CROSSCHECK'        => 'For CrossCheck',
        'LBL_DULICATECHECK_RULE_FOR'    => 'Duplicate Check Rule For',
        'LBL_ENABLE'                    => 'Enable',
        'LBL_DISABLE'                   => 'Disable',
        'LBL_CONFIGURE_FIELD_RULE'      => 'Configure Field Rule',
        'LBL_CHOOSE_CHECK_MODULE'       => 'To choose what to check in this module',
        'LBL_CHECK_DUPLICATE'           => 'Check Duplicates across Contacts , Leads and Organization for Email and Phone Field',
);
