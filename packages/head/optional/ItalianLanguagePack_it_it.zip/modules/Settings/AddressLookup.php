<?php

$languageStrings = array(
        'AddressLookup'         => 'Ricerca indirizzo',
        'Address Lookup'        => 'Ricerca indirizzo',
        'LBL_STREET'            => 'strada',
        'LBL_ENTER_API_KEY'     => 'Inserisci la tua chiave API',
        'LBL_CLICK_TO_CREATE_API_KEY'   => 'Fai clic qui per creare la chiave API',
        'LBL_AREA'                      => 'La zona',
        'LBL_LOCALITY'                  => 'Località',
        'LBL_CITY'                      => 'Città',
        'LBL_STATE'                     => 'Stato',
        'LBL_COUNTRY'                   => 'Nazione',
        'LBL_POSTAL_CODE'               => 'codice postale',
        'LBL_ACTION'                    => 'Azione',
        'LBL_CONFIGURE_MAPPING_FOR'     => 'Configurare la mappatura del campo per',
);
