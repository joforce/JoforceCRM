<?php

$languageStrings = array(
        'DuplicateCheck' => 'Verifica duplicata',
        'Duplicate Check' => 'Verifica duplicata',
        'LBL_DUPLICATECHECK_INFORMATION' => 'Duplica informazioni di controllo',
        'LBL_CLICK'             => 'Clic',
        'LBL_CROSSCHECK'        => 'Per Cross Check',
        'LBL_DULICATECHECK_RULE_FOR'    => 'Duplica regola di controllo per',
        'LBL_ENABLE'                    => 'Abilitare',
        'LBL_DISABLE'                   => 'disattivare',
        'LBL_CONFIGURE_FIELD_RULE'      => 'Configura regola di campo',
        'LBL_CHOOSE_CHECK_MODULE'       => 'Per scegliere cosa controllare in questo modulo',
        'LBL_CHECK_DUPLICATE'           => "Controlla i duplicati attraverso i contatti, i lead e l'organizzazione per il campo email e telefono",
);
