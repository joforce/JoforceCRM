<?php

$languageStrings = array(
        'SINGLE_PDFMaker' => 'Creatore di PDF',
        'PDFMaker' => 'Creatore di PDF',
        'LBL_NAME' => 'Nome',
        'LBL_DESCRIPTION' => 'Descrizione',
        'LBL_TEMPLATE' => 'Modello',
        'LBL_PDFMAKER_INFORMATION' => 'Informazioni sul creatore PDF',
        'LBL_SELECT_FIELD_TYPE' => 'Seleziona Tipo',
        'LBL_NO_TEMPLATE' => 'Nessun modello esiste per questo modulo',
        'LBL_GENERAL' => 'Generale',
        'LBL_COMPANY_INFO' => "Informazioni sull'azienda",
);
