<?php
$languageStrings = array(
        'LBL_ACCOUNT_TYPE'      =>'Tipo di account',
        'LBL_SERVER_NAME'       =>'Nome del server' ,
        'LBL_PORT'              =>'Porta',
        'LBL_EMAIL'             =>'E-mail primario',
        'LBL_PASSWORD'          =>"Parola d'ordine",
);
