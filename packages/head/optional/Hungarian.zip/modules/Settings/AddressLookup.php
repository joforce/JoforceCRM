<?php

$languageStrings = array(
        'AddressLookup'         => 'Címkeresés',
        'Address Lookup'        => 'Címkeresés',
        'LBL_STREET'            => 'utca',
        'LBL_ENTER_API_KEY'     => 'Adja meg az API kulcsát',
        'LBL_CLICK_TO_CREATE_API_KEY'   => 'Kattintson ide az API-kulcs létrehozásához',
        'LBL_AREA'                      => 'Terület',
        'LBL_LOCALITY'                  => 'Helység',
        'LBL_CITY'                      => 'Város',
        'LBL_STATE'                     => 'Állapot',
        'LBL_COUNTRY'                   => 'Ország',
        'LBL_POSTAL_CODE'               => 'Irányítószám',
        'LBL_ACTION'                    => 'Akció',
        'LBL_CONFIGURE_MAPPING_FOR'     => 'A térképezés beállítása',
);
