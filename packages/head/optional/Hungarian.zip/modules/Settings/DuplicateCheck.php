<?php

$languageStrings = array(
        'DuplicateCheck' => 'Duplikált ellenőrzés',
        'Duplicate Check' => 'Duplikált ellenőrzés',
        'LBL_DUPLICATECHECK_INFORMATION' => 'Duplikált ellenőrzési információk',
        'LBL_CLICK'             => 'Kattints',
        'LBL_CROSSCHECK'        => 'Keresztellenőrzéshez',
        'LBL_DULICATECHECK_RULE_FOR'    => 'Duplikált ellenőrzési szabály',
        'LBL_ENABLE'                    => 'Engedélyezze',
        'LBL_DISABLE'                   => 'letiltása',
        'LBL_CONFIGURE_FIELD_RULE'      => 'Mező szabály megadása',
        'LBL_CHOOSE_CHECK_MODULE'       => 'Annak kiválasztása, hogy mit kell ellenőriznie ebben a modulban',
        'LBL_CHECK_DUPLICATE'           => 'Ellenőrizze az átnevezéseket az e-mailben és a telefonmezőben lévő kapcsolatok, vezetők és szervezetek számára',
);
