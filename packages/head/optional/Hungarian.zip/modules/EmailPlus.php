<?php
$languageStrings = array(
        'LBL_ACCOUNT_TYPE'      =>'Fiók Típus',
        'LBL_SERVER_NAME'       =>'Szerver név' ,
        'LBL_PORT'              =>'Kikötő',
        'LBL_EMAIL'             =>'Elsődleges email',
        'LBL_PASSWORD'          =>'Jelszó',
);
