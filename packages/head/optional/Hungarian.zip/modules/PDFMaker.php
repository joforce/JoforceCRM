<?php

$languageStrings = array(
        'SINGLE_PDFMaker' => 'PDF Maker',
        'PDFMaker' => 'PDF Maker',
        'LBL_NAME' => 'Név',
        'LBL_DESCRIPTION' => 'Leírás',
        'LBL_TEMPLATE' => 'Sablon',
        'LBL_PDFMAKER_INFORMATION' => 'PDFMaker információk',
        'LBL_SELECT_FIELD_TYPE' => 'Válassza a Típus lehetőséget',
        'LBL_NO_TEMPLATE' => 'Ehhez a modulhoz nincs sablon',
        'LBL_GENERAL' => 'Tábornok',
        'LBL_COMPANY_INFO' => 'Céginformációk'
);
