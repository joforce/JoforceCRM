<?php

$languageStrings = array(
        'DuplicateCheck' => 'Yinelenen Çek',
        'Duplicate Check' => 'Yinelenen Çek',
        'LBL_DUPLICATECHECK_INFORMATION' => 'Yinelenen Çek bilgisi',
        'LBL_CLICK'             => 'Click',
        'LBL_CROSSCHECK'        => 'Çapraz Kontrol için',
        'LBL_DULICATECHECK_RULE_FOR'    => 'Için Yinelenen Kontrol Kuralı',
        'LBL_ENABLE'                    => 'etkinleştirme',
        'LBL_DISABLE'                   => 'Devre dışı',
        'LBL_CONFIGURE_FIELD_RULE'      => 'Saha Kuralını Yapılandır',
        'LBL_CHOOSE_CHECK_MODULE'       => 'Bu modülde neyin kontrol edileceğini seçmek için',
        'LBL_CHECK_DUPLICATE'           => 'E-posta ve Telefon Alanında Kişiler, İlanlar ve Organizasyon Üzerinden Çoğaltmaları Kontrol Etme',
);
