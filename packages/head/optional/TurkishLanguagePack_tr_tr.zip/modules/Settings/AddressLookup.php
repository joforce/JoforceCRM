<?php

$languageStrings = array(
        'AddressLookup'         => 'Adres Arama',
        'Address Lookup'        => 'Adres Arama',
        'LBL_STREET'            => 'sokak',
        'LBL_ENTER_API_KEY'     => 'API Anahtarınızı Girin',
        'LBL_CLICK_TO_CREATE_API_KEY'   => 'API Anahtarı Oluşturmak İçin Buraya Tıklayın',
        'LBL_AREA'                      => 'alan',
        'LBL_LOCALITY'                  => 'mekân',
        'LBL_CITY'                      => 'Kent',
        'LBL_STATE'                     => 'Belirtmek, bildirmek',
        'LBL_COUNTRY'                   => 'ülke',
        'LBL_POSTAL_CODE'               => 'posta kodu',
        'LBL_ACTION'                    => 'Aksiyon',
        'LBL_CONFIGURE_MAPPING_FOR'     => 'Alan Eşlemesini Yapılandır',
);
