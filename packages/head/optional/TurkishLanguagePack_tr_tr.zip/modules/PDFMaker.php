<?php

$languageStrings = array(
        'SINGLE_PDFMaker' => 'PDF oluşturucu',
        'PDFMaker' => 'PDF oluşturucu',
        'LBL_NAME' => 'isim',
        'LBL_DESCRIPTION' => 'Açıklama',
        'LBL_TEMPLATE' => 'şablon',
        'LBL_PDFMAKER_INFORMATION' => 'PDF yapımcı bilgisi',
        'LBL_SELECT_FIELD_TYPE' => 'Türü Seç',
        'LBL_NO_TEMPLATE' => 'Bu modül için şablon yok',
        'LBL_GENERAL' => 'Genel',
        'LBL_COMPANY_INFO' => 'Şirket bilgileri'
);
