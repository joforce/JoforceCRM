<?php

$languageStrings = array(
        'SINGLE_PDFMaker' => 'PDF Maker',
        'PDFMaker' => 'PDF Maker',
        'LBL_NAME' => 'prénom',
        'LBL_DESCRIPTION' => 'La description',
        'LBL_TEMPLATE' => 'Modèle',
        'LBL_PDFMAKER_INFORMATION' => 'Informations sur PDF Maker',
        'LBL_SELECT_FIELD_TYPE' => 'Sélectionner le genre',
        'LBL_NO_TEMPLATE' => "Aucun modèle n'existe pour ce module",
        'LBL_GENERAL' => 'Général',
        'LBL_COMPANY_INFO' => 'Informations sur la société',
);
