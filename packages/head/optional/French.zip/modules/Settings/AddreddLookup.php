<?php

$languageStrings = array(
        'AddressLookup'         => "Recherche d'adresse",
        'Address Lookup'        => "Recherche d'adresse",
        'LBL_STREET'            => 'rue',
        'LBL_ENTER_API_KEY'     => "Entrez votre clé d'API",
        'LBL_CLICK_TO_CREATE_API_KEY'   => "Cliquez ici pour créer une clé API",
        'LBL_AREA'                      => 'Région',
        'LBL_LOCALITY'                  => 'Localité',
        'LBL_CITY'                      => 'Ville',
        'LBL_STATE'                     => 'Etat',
        'LBL_COUNTRY'                   => 'Pays',
        'LBL_POSTAL_CODE'               => 'code postal',
        'LBL_ACTION'                    => 'action',
        'LBL_CONFIGURE_MAPPING_FOR'     => 'Configurer le mappage de champ pour',
);
