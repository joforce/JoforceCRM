<?php

$languageStrings = array(
        'DuplicateCheck' => 'Vérification en double',
        'Duplicate Check' => 'Vérification en double',
        'LBL_DUPLICATECHECK_INFORMATION' => 'Informations de vérification en double',
        'LBL_CLICK'             => 'Cliquez sur',
        'LBL_CROSSCHECK'        => 'Pour Cross Check',
        'LBL_DULICATECHECK_RULE_FOR'    => 'Règle de contrôle en double pour',
        'LBL_ENABLE'                    => 'Activer',
        'LBL_DISABLE'                   => 'Désactiver',
        'LBL_CONFIGURE_FIELD_RULE'      => 'Configurer la règle de champ',
        'LBL_CHOOSE_CHECK_MODULE'       => "Choisir ce qu'il faut vérifier dans ce module",
        'LBL_CHECK_DUPLICATE'           => "iVérifier les doublons dans les contacts, les pistes et l'organisation pour le domaine du courrier électronique et du téléphone",
);
