<?php
$languageStrings = array(
        'LBL_ACCOUNT_TYPE'      =>'Type de compte',
        'LBL_SERVER_NAME'       =>'Nom du serveur' ,
        'LBL_PORT'              =>'Port',
        'LBL_EMAIL'             =>'Email principal',
        'LBL_PASSWORD'          =>'Mot de passe',
);
