<?php

$languageStrings = array(
        'AddressLookup'         => 'بحث العنوان',
        'Address Lookup'        => 'بحث العنوان',
        'LBL_STREET'            => 'شارع',
        'LBL_ENTER_API_KEY'     => 'أدخل مفتاح API الخاص بك',
        'LBL_CLICK_TO_CREATE_API_KEY'   => 'انقر هنا لإنشاء API الرئيسية',
        'LBL_AREA'                      => 'منطقة',
        'LBL_LOCALITY'                  => 'مكان',
        'LBL_CITY'                      => 'مدينة',
        'LBL_STATE'                     => 'حالة',
        'LBL_COUNTRY'                   => 'بلد',
        'LBL_POSTAL_CODE'               => 'الرمز البريدي',
        'LBL_ACTION'                    => 'عمل',
        'LBL_CONFIGURE_MAPPING_FOR'     => 'تكوين حقل رسم ل',
);
