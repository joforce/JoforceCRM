<?php

$languageStrings = array(
        'DuplicateCheck' => 'تحقق مكرر',
        'Duplicate Check' => 'تحقق مكرر',
        'LBL_DUPLICATECHECK_INFORMATION' => 'ﺖﺤﻘﻗ ﻢﻛﺭﺭ معلومات',
        'LBL_CLICK'             => 'انقر',
        'LBL_CROSSCHECK'        => 'لفحص الصليب',
        'LBL_DULICATECHECK_RULE_FOR'    => 'ﺖﺤﻘﻗ ﻢﻛﺭﺭ حكم ل',
        'LBL_ENABLE'                    => 'مكن',
        'LBL_DISABLE'                   => 'تعطيل',
        'LBL_CONFIGURE_FIELD_RULE'      => 'تكوين قاعدة المجال',
        'LBL_CHOOSE_CHECK_MODULE'       => 'لاختيار ما تحقق في هذه الوحدة',
        'LBL_CHECK_DUPLICATE'           => 'تحقق من التكرارات عبر جهات الاتصال ، العملاء المحتملون و المنظمة الخاصة بمجال البريد الإلكتروني والهاتف',

);
