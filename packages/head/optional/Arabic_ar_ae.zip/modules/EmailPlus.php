<?php
$languageStrings = array(
        'LBL_ACCOUNT_TYPE'      =>'نوع الحساب',
        'LBL_SERVER_NAME'       =>'اسم الخادم' ,
        'LBL_PORT'              =>'ميناء',
        'LBL_EMAIL'             =>'البريد الإلكتروني الرئيسي',
        'LBL_PASSWORD'          =>'كلمه السر',
);
