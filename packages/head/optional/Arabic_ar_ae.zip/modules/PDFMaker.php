<?php

$languageStrings = array(
        'SINGLE_PDFMaker' => 'قوات الدفاع الشعبي صانع',
        'PDFMaker' => 'قوات الدفاع الشعبي صانع',
        'LBL_NAME' => 'اسم',
        'LBL_DESCRIPTION' => 'وصف',
        'LBL_TEMPLATE' => 'قالب',
        'LBL_PDFMAKER_INFORMATION' => 'ﻕﻭﺎﺗ ﺎﻟﺪﻓﺎﻋ ﺎﻠﺸﻌﺒﻳ ﺹﺎﻨﻋ معلومات',
        'LBL_SELECT_FIELD_TYPE' => 'اختر صنف',
        'LBL_NO_TEMPLATE' => 'لا يوجد قالب لهذه الوحدة',
        'LBL_GENERAL' => 'جنرال لواء',
        'LBL_COMPANY_INFO' => 'معلومات الشركة'
);

?>
