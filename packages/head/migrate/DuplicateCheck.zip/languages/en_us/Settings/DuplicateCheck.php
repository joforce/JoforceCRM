<?php

$languageStrings = array(
	'DuplicateCheck' => 'Duplicate Check',
	'Duplicate Check' => 'Duplicate Check',
	'LBL_DUPLICATECHECK_INFORMATION' => 'DuplicateCheck Information',
);
