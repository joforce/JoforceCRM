<?php
class Settings_DuplicateCheck_ModuleManager_View extends Settings_Head_Index_View
{
	public function __construct()
	{
		parent::__construct();
	}

	public function process(Head_Request $request)
	{
		global $adb;
		$module = $_REQUEST['mod'];
		$mode   = $_REQUEST['mode'];

		if(empty($module) || trim($module) == '' || empty($mode) || trim($mode) == '')
		{
			die('FAILURE');
		}

		$enable = 0;
		if($mode == 'enable')	
		{
			$enable = 1;
		}

		$result = $adb->pquery("update jo_vtduplicatechecksettings set isenabled = ? where modulename = ?", array($enable, $module));
		if($result)	
		{	
			die('SUCCESS');		
		}
		die('FAILURE');
	}
}
