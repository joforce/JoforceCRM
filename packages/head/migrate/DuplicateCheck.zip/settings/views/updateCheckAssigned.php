<?php
class Settings_DuplicateCheck_updateCheckAssigned_View extends Settings_Head_Index_View
{
	public function __construct()
	{
		parent::__construct();
	}

	public function process(Head_Request $request)
	{
		global $adb;
		$checked = $_REQUEST['checked'];
		$isenabled = 0;
		if($checked == 'true')
			$isenabled = 1;

		$adb->pquery("update jo_vtduplicatechecksettings set isenabled = ? where modulename = ?",array( $isenabled, 'assignedto'));
		die('SUCCESS');
	}
}
