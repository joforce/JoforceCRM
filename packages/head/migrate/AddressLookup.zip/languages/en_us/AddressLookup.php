<?php

$languageStrings = array(
	'AddressLookup' => 'Address Lookup',
	'Address Lookup' => 'Address Lookup'
);
